"use strict";

const ASU_LONG = 33.4187;
const ASU_LAT = -111.9347;
const ZOOM = 16;

const apiURL = "https://9j600ki9gk.execute-api.us-west-2.amazonaws.com/default/scoot-radar";

const map = new L.Map("mapid", {
    center: [ASU_LONG, ASU_LAT],
    zoom: ZOOM,
    maxZoom: ZOOM + 2
}).addLayer(new L.TileLayer("https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png"));

// this is the first function that gets called when our web page loads
$(document).ready(function () {
    getLiveData();
    initializeDayPicker();
    initLiveData();
});

function initializeDayPicker() {
    let date_input = $('input[name="date"]'); //our date input has the name "date"
    let container = "body";
    let options = {
        format: 'mm/dd/yyyy',
        container: container,
        todayHighlight: true,
        autoclose: true,
        orientation: "bottom-right"
    };
    date_input.datepicker(options)
        .on('changeDate', dateChanged);
}

function dateChanged() {
    $('#live-btn').css('color', '#8e8e8e');
    console.log('dateChanged');
    console.log($('#date-picker').val())
}

function getLiveData() {
    $.ajax({
        type: 'GET',
        url: apiURL,
        success: (response) => {
            console.log('AJAX successful');
            let data = JSON.parse(response);
            let birds = data.birds;
            addHeat(birds);
        },
        error: (error) => {
            console.error(error);
        }
    });
}

function initLiveData() {
    console.log('live data init clicked');
    $('#live-btn').css('color', '#ffffff');
    $('#date-picker').val('').datepicker('update');
}

function getStoredData(date) {
    alert('getStoredData handler fired');

    // $.ajax({
    //     type: 'GET',
    //     url: apiURL,
    //     data: `date=${date}`,
    //     success: (response) => {
    //         console.log('AJAX successful');
    //         let data = JSON.parse(response);
    //         let birds = data.birds;
    //         addHeat(birds);
    //     }, 
    //     error: (error) => {
    //         console.error(error);
    //     } 
    // });
}

function addHeat(birds) {
    // we need an array of coordinates for the heat map
    let birdLocations = [];

    // iterate birds: push latitude, longitude, and 1 for radius of the heat circles
    for (let bird of birds) {
        birdLocations.push([bird.location.latitude, bird.location.longitude, 1]);
    }

    // using birdLocations array, add heat circles to our map object
    let heat = L.heatLayer(birdLocations, {
        radius: 20,
        blur: 15,
        maxZoom: 17,
    }).addTo(map);

    console.log(`data added for ${birds.length} birds`);
}